from random import *


def randomT(a: any, b: any) -> any:
    return a if randint(0, 1) else b

def valueIsInt(v: str) -> bool:
    return v.replace("-", "").isdigit() and v.count("-") <= 1 and (v.count("-") == 0 or v[0] == "-")

class Player():
    def __init__(self, name:str) -> None:
        self.name = name
        self.deck = []
        self.hand = []
        self.graveyard = []
        self.in_play = []
        self.shuffle_pile = []
        self.discard_pile = []
        
    def load_deck(self) -> None:
        with open(self.name+".txt", 'r', encoding='utf-8') as file:
            self.deck = [line.strip() for line in file.readlines()]
        self.shuffle_pile.extend(self.deck)
        shuffle(self.shuffle_pile)
            
    def draw_card(self) -> str:
        if self.shuffle_pile:
            card = self.shuffle_pile.pop()
            self.hand.append(card)
            print(f"抽到的牌:{card}")
            return card
        else:
            self.shuffle_pile.extend(self.discard_pile)
            self.discard_pile = []
            shuffle(self.discard_pile)
            if self.shuffle_pile:
                card = self.shuffle_pile.pop()
                self.hand.append(card)
                print(f"抽到的牌:{card}")
                return card
            else:
                print(f"無效動作: 牌堆已空")
                return None
                
    
    def play_card(self) -> int:
        print(f"\n0.抽牌 1.使用牌 2.將使用的牌丟進棄牌堆 3.使用的牌丟進獻祭堆 4.將獻祭堆的牌放回手牌 5.從抽牌堆拿到手牌 exit:退出")
        action = input("輸入動作:")
        print("\n"*3)
        if action == "0":
            self.draw_card()
            
        elif action.isdigit():
            if action == "1":
                print("\n"*3+"手牌:", self.displayCarddeckInfo(self.hand))
                index = input("\n"*5+"使用的牌:")
                
                if valueIsInt(index) and -len(self.hand) < int(index) < len(self.hand):
                    self.in_play.append(self.hand.pop(int(index)))
                else:
                    if index == "" and len(self.hand):
                        index = input("再按一次ENTER則自動使用最後一張牌 其餘則退出")
                        if index == "":
                            self.in_play.append(self.hand.pop(int(-1)))
                        else:
                            print("退出")
                    else:
                        print("無效動作")
                
            elif action == "2":
                print("\n"*3+"場上堆:", self.displayCarddeckInfo(self.in_play))
                index = input("\n"*5+"使用的牌:")

                if valueIsInt(index) and -len(self.in_play) < int(index) < len(self.in_play):
                    self.discard_pile.append(self.in_play.pop(int(index)))
                else:
                    if index == "" and len(self.in_play):
                        index = input("再按一次ENTER則自動使用最後一張牌 其餘則退出:")
                        if index == "":
                            self.discard_pile.append(self.in_play.pop(int(-1)))
                        else:
                            print("退出")
                    else:
                        print("無效動作")
                
            elif action == "3":
                print("\n"*3+"場上堆:", self.displayCarddeckInfo(self.in_play))
                index = input("\n"*5+"使用的牌:")
                
                if valueIsInt(index) and -len(self.in_play) < int(index) < len(self.in_play):
                    self.graveyard.append(self.in_play.pop(int(index)))
                else:
                    if index == "" and len(self.in_play):
                        index = input("再按一次ENTER則自動使用最後一張牌 其餘則退出")
                        if index == "":
                            self.graveyard.append(self.in_play.pop(int(-1)))
                        else:
                            print("退出")
                    else:
                        print("無效動作")
                    
            elif action == "4":
                print("\n"*3+"獻祭堆:", self.displayCarddeckInfo(self.graveyard))
                index = input("\n"*5+"使用的牌:")
                
                if valueIsInt(index) and -len(self.graveyard) < int(index) < len(self.graveyard):
                    self.hand.append(self.graveyard.pop(int(index)))
                else:
                    if index == "" and len(self.graveyard):
                        index = input("再按一次ENTER則自動使用最後一張牌 其餘則退出")
                        if index == "":
                            self.hand.append(self.graveyard.pop(int(-1)))
                        else:
                            print("退出")
                    else:
                        print("無效動作")
                        
            elif action == "5":
                tempShuffle = list(set(self.shuffle_pile))
                print("\n"*3+"抽牌堆(無序):", self.displayCarddeckInfo(tempShuffle))
                index = input("\n"*5+"使用的牌:")
                
                if valueIsInt(index) and -len(tempShuffle) < int(index) < len(tempShuffle):
                    card = tempShuffle[int(index)]
                    f, b = self.shuffle_pile.index(card), -list(reversed(self.shuffle_pile)).index(card)-1
                    self.hand.append(self.shuffle_pile.pop(randomT(f,b)))
                else:
                    print("無效動作")

        elif action.lower() == "exit":
            return 0
        else:
            print("無效動作")
        
        self.display_status()
        return 1
    
    def displayCarddeckInfo(self, List: list[str]) -> str:
        return ", ".join(list(str(i)+"-"+v for i, v in enumerate(List)))
    
    def display_status(self):
        print("\n")
        print("玩家名子:", self.name)
        print("抽牌堆剩於牌數:", len(self.shuffle_pile))
        print("手牌:", self.displayCarddeckInfo(self.hand))
        print("\n場上牌:", self.displayCarddeckInfo(self.in_play))
        print("\n棄牌堆:", " ".join(self.discard_pile))
        print("獻祭堆:", " ".join(self.graveyard))
        


def main() -> int:

    print("(請確認你角色名與你的牌堆txt檔名一樣無誤)")
    name = input("\n輸入角色1名子:")
    
    player = Player(name)
    
    try:
        player.load_deck()
    except:
        print("無法載入檔案\n(請確認你的角色名與檔名一樣)")
        return -1
        
    
    while player.play_card(): pass
    return 0
    
    
    
    
    
    
if __name__ == "__main__":
    main()