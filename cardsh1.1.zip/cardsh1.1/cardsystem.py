import random
from typing import Any

def valueIsInt(v: str) -> bool:
    return v.replace("-", "").isdigit() and v.count("-") <= 1 and (v.count("-") == 0 or v[0] == "-")

def getIndices(lst: tuple[Any], targets: tuple[Any]) -> list[int]:
    return list(filter(lambda x: lst[x] in targets, range(len(lst))))

def getElements(lst: tuple[Any], targets: tuple[Any]) -> list[Any]:
    return list(filter(lambda x: x in targets, lst))

def deleteElements(lst: list[Any], targets: tuple[Any], start: int=0, end: int=-1, step: int=1) -> list[Any]:
    deleteIdices = sorted(getIndices(lst[start:end:step], targets), reverse=True)
    for i in deleteIdices:
        if step == -1:
            lst.pop(-1-i) 
        else:
            lst.pop(i)
    return lst

class Player():
    def __init__(self, name:str) -> None:
        self.name = name
        self.deck = []
        self.hand = []
        self.graveyard = []
        self.inPlay = []
        self.shufflePile = []
        self.discardPile = []

    def loadDeck(self) -> None:
        with open(self.name+".txt", 'r', encoding='utf-8') as file:
            self.deck = [line.strip() for line in file.readlines()]
        self.shufflePile.extend(self.deck)
        random.shuffle(self.shufflePile)

    def drawCard(self) -> str:
        if self.shufflePile:
            card = self.shufflePile.pop()
            self.hand.append(card)
            print(f"抽到的牌:{card}")
            return card
        else:
            self.shufflePile.extend(self.discardPile)
            self.discardPile = []
            random.shuffle(self.discardPile)
            if self.shufflePile:
                card = self.shufflePile.pop()
                self.hand.append(card)
                print(f"抽到的牌:{card}")
                return card
            else:
                print(f"無效動作: 牌堆已空")
                return None

    def useCard(self, cardSourceName: str, cardSource: list[str], cardDestinationName: str, cardDestination: list[str]) -> bool:
        print("\n"*3+f"{cardSourceName}:", self.displayCarddeckInfo(cardSource))
        index = input("\n"*5+"使用的牌:")
        
        if valueIsInt(index) and -len(cardSource) < int(index) < len(cardSource):
            cardDestination.append(cardSource.pop(int(index)))
            return True
        else:
            if index == "" and len(cardSource):
                index = input("再按一次ENTER則自動使用最後一張牌 其餘則退出")
                if index == "":
                    cardDestination.append(cardSource.pop(int(-1)))
                    return True
                else:
                    print("退出")
                    return False
            else:
                print("無效動作")
                return False
    
    def selectCardFromDisorderPile(self, cardSourceName: str, cardSource: list[str], cardDestinationName: str, cardDestination: list[str], all: bool=False) -> bool:
        tempShuffle = list(set(cardSource))
        print("\n"*3+f"{cardSourceName}(無序):", self.displayCarddeckInfo(tempShuffle))
        index = input("\n"*5+"使用的牌(若該牌堆中有超過一張同名的卡則隨機拿走一張):" if not all else "\n"*5+f"使用的牌({cardSourceName}中同名的卡都會拿走):")
        
        if valueIsInt(index) and -len(tempShuffle) < int(index) < len(tempShuffle):
            if all:
                card = tempShuffle[int(index)]
                cardDestination += getElements(cardSource, (card))
                deleteElements(cardSource, (card))
            else:
                card = tempShuffle[int(index)]
                cardDestination.append(cardSource.pop(random.choice(getIndices(cardSource, (card)))))
            return True
        else:
            print("無效動作")
            return False
    
    def selectCardFromOrderedPile(self, cardSourceName: str, cardSource: list[str], cardDestinationName: str, cardDestination: list[str], reveal: int=-1, all: bool=False) -> bool:
        reveal = reveal if reveal != -1 else len(cardSource)
        tempShuffle = cardSource[len(cardSource)-1:len(cardSource)-1-reveal:-1]
        print("\n"*3+f"{cardSourceName}(前{reveal}張):", self.displayCarddeckInfo(tempShuffle))
        index = input("\n"*5+"使用的牌:" if not all else "\n"*5+f"使用的牌({cardSourceName}中前{reveal}張同名的卡都會拿走):")
        
        if valueIsInt(index) and -len(tempShuffle) < int(index) < len(tempShuffle):
            if all:
                card = tempShuffle[int(index)]
                cardDestination += getElements(cardSource[len(cardSource)-1:len(cardSource)-1-reveal:-1], (card))
                deleteElements(cardSource, (card), start=len(cardSource)-1, end=len(cardSource)-1-reveal, step=-1)
            else:
                cardDestination.append(cardSource.pop(-1-index))
            return True
        else:
            print("無效動作")
            return False
    
    def playCard(self) -> int:
        print(f"\n0.抽牌 1.使用牌 2.將使用的牌丟進棄牌堆 3.使用的牌丟進獻祭堆 4.將獻祭堆的牌放回手牌 5.從抽牌堆拿到手牌 6.特殊卡牌功能 exit:退出")
        action = input("輸入動作:")
        print("\n"*3)
            
        match action:
            case "0":
                self.drawCard()
                
            case "1":
                self.useCard("手牌", self.hand, "場上堆", self.inPlay)
                
            case "2":
                self.useCard("場上堆", self.inPlay, "棄牌堆", self.discardPile)
                
            case "3":
                self.useCard("場上堆", self.inPlay, "獻祭堆", self.graveyard)
                
            case "4":
                self.useCard("獻祭堆", self.graveyard, "手牌", self.hand)

            case "5":
                self.selectCardFromDisorderPile("抽牌堆", self.shufflePile, "手牌", self.hand)

            case "6":
                self.specialCard()

            case "exit":
                return 0

            case _:
                print("無效動作")
        
        self.displayStatus()
        return 1
    
    def specialCard(self) -> bool:
        self.displayStatus()
        print(f"\n0.從棄牌堆拿到手牌 1.強充能 exit:退出")
        action = input("輸入動作:")
        print("\n"*3)
        
        match action:
            case "0":
                self.useCard("棄牌堆", self.discardPile, "手牌", self.hand)
                
            case "1":
                self.selectCardFromOrderedPile("抽牌堆", self.shufflePile, "手牌", self.hand, reveal=5, all=True)

            case "exit":
                return False

            case _:
                print("無效動作")
        return False
    
    def displayCarddeckInfo(self, lst: list[str]) -> str:
        return ", ".join(list(str(i)+"-"+v for i, v in enumerate(lst)))
    
    def displayStatus(self):
        print("\n")
        print("玩家名子:", self.name)
        print("抽牌堆剩於牌數:", len(self.shufflePile))
        print("手牌:", self.displayCarddeckInfo(self.hand))
        print("\n場上堆:", self.displayCarddeckInfo(self.inPlay))
        print("\n棄牌堆:", " ".join(self.discardPile))
        print("獻祭堆:", " ".join(self.graveyard))
        


def main() -> int:

    print("(請確認你角色名與你的牌堆txt檔名一樣無誤)")
    name = input("\n輸入角色1名子:")
    
    player = Player(name)
    
    try:
        player.loadDeck()
    except:
        print("無法載入檔案\n(請確認你的角色名與檔名一樣)")
        return -1
        
    
    while player.playCard(): pass
    return 0
    
    
if __name__ == "__main__":
    main()