import numpy as np

c, n = map(int, input().split())
w, v = list(map(int, input().split())), list(map(int, input().split()))

f = np.zeros((n+1, c+1), dtype=int)

for i in range(1, n+1):
    for j in range(c+1):
        if j < w[i-1]:
            f[i, j] = f[i-1, j]
        else:
            f[i, j] = max(f[i-1, j], f[i-1, j-w[i-1]] + v[i-1])

print(f[n, c])

print(f)
# import numpy as np
# from numpy import random

# x = random.choice([3, 5, 7, 9], size=(3, 5))

# print(x)