from random import *


def randomT(a: any, b: any) -> any:
    return a if randint else b

class Player():
    def __init__(self, name:str) -> None:
        self.name = name
        self.deck = []
        self.hand = []
        self.graveyard = []
        self.in_play = []
        self.shuffle_pile = []
        self.discard_pile = []
        
    def load_deck(self) -> None:
        with open(self.name+".txt", 'r', encoding='utf-8') as file:
            self.deck = [line.strip() for line in file.readlines()]
        self.shuffle_pile.extend(self.deck)
        shuffle(self.shuffle_pile)
            
    def draw_card(self) -> str:
        if self.shuffle_pile:
            card = self.shuffle_pile.pop()
            self.hand.append(card)
            print(f"抽到的牌:{card}")
        else:
            self.shuffle_pile.extend(self.discard_pile)
            self.discard_pile = []
            shuffle(self.discard_pile)
            if self.shuffle_pile:
                card = self.shuffle_pile.pop()
                self.hand.append(card)
                print(f"抽到的牌:{card}")
            else:
                print(f"無效動作: 牌堆已空")
                
    
    def play_card(self) -> None:
        print(f"\n0.抽牌 1.使用牌 2.將使用的牌丟進棄牌堆 3.使用的牌丟進獻祭堆 4.將獻祭堆的牌放回手牌 5.從抽牌堆拿到手牌 exit:退出")
        action = input("輸入動作:")
        print("\n"*3)
        if action.isdigit() and action == "0":
            self.draw_card()
            
        elif action.isdigit() and action == "1":
            print("\n"*3+"手牌:", ", ".join(list(str(i[0])+"-"+i[1] for i in enumerate(self.hand))))
            index = input("\n"*5+"使用的牌:")
            
            if index.replace("-","").isdigit() and -len(self.hand) < int(index) < len(self.hand):
                self.in_play.append(self.hand.pop(int(index)))
            else:
                if index == "" and len(self.hand):
                    index = input("再按一次ENTER則自動使用最後一張牌 其餘則退出")
                    if index == "":
                        self.in_play.append(self.hand.pop(int(-1)))
                    else:
                        print("退出")
                else:
                    print("無效動作")
            
        elif action.isdigit() and action == "2":
            print("\n"*3+"場上堆:", ", ".join(list(str(i[0])+"-"+i[1] for i in enumerate(self.in_play))))
            index = input("\n"*5+"使用的牌:")

            if index.replace("-","").isdigit() and -len(self.in_play) < int(index) < len(self.in_play):
                self.discard_pile.append(self.in_play.pop(int(index)))
            else:
                if index == "" and len(self.in_play):
                    index = input("再按一次ENTER則自動使用最後一張牌 其餘則退出:")
                    if index == "":
                        self.discard_pile.append(self.in_play.pop(int(-1)))
                    else:
                        print("退出")
                else:
                    print("無效動作")
            
        elif action.isdigit() and action == "3":
            print("\n"*3+"場上堆:", ", ".join(list(str(i[0])+"-"+i[1] for i in enumerate(self.in_play))))
            index = input("\n"*5+"使用的牌:")
            
            if index.replace("-","").isdigit() and -len(self.in_play) < int(index) < len(self.in_play):
                self.graveyard.append(self.in_play.pop(int(index)))
            else:
                if index == "" and len(self.in_play):
                    index = input("再按一次ENTER則自動使用最後一張牌 其餘則退出")
                    if index == "":
                        self.graveyard.append(self.in_play.pop(int(-1)))
                    else:
                        print("退出")
                else:
                    print("無效動作")
                
        elif action.isdigit() and action == "4":
            print("\n"*3+"獻祭堆:", ", ".join(list(str(i[0])+"-"+i[1] for i in enumerate(self.graveyard))))
            index = input("\n"*5+"使用的牌:")
            
            if index.replace("-","").isdigit() and -len(self.graveyard) < int(index) < len(self.graveyard):
                self.hand.append(self.graveyard.pop(int(index)))
            else:
                if index == "" and len(self.graveyard):
                    index = input("再按一次ENTER則自動使用最後一張牌 其餘則退出")
                    if index == "":
                        self.hand.append(self.graveyard.pop(int(-1)))
                    else:
                        print("退出")
                else:
                    print("無效動作")
                     
        elif action.isdigit() and action == "5":
            print("\n"*3+"抽牌堆(無序):", ", ".join(list(str(i[0])+"-"+i[1] for i in enumerate(set(self.shuffle_pile)))))
            index = input("\n"*5+"使用的牌:")
            
            if index.replace("-","").isdigit() and -len(set(self.shuffle_pile)) < int(index) < len(set(self.shuffle_pile)):
                card = list(set(self.shuffle_pile))[int(index)]
                f, b = self.shuffle_pile.index(card), list(reversed(self.shuffle_pile)).index(card)
                self.hand.append(self.shuffle_pile.pop(randomT(f,b)))
            else:
                print("無效動作")

        elif action.lower() == "exit":
            quit()
        else:
            print("無效動作")
        
        self.display_status()
            
    def display_status(self):
        print("\n")
        print("玩家名子:", self.name)
        print("抽牌堆剩於牌數:", len(self.shuffle_pile))
        print("手牌:", ", ".join(list(str(i[0])+"-"+i[1] for i in enumerate(self.hand))))
        print("\n場上牌:", ", ".join(list(str(i[0])+"-"+i[1] for i in enumerate(self.in_play))))
        print("\n棄牌堆:", " ".join(self.discard_pile))
        print("獻祭堆:", " ".join(self.graveyard))
        


def main():

    print("(請確認你角色名與你的牌堆txt檔名一樣無誤)")
    name = input("\n輸入角色1名子:")
    
    player = Player(name)
    
    player.load_deck()
    try:
        pass
        
    except:
        print("無法載入檔案\n(請確認你的角色名與檔名一樣)")
        return 0
        
    
    running = True
    
    while running:
    
        player.play_card()
    
    
    
    
    
    
if __name__ == "__main__":
    main()